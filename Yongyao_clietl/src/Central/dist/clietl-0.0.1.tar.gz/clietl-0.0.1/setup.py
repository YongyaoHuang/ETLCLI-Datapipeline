# -*- coding: utf-8 -*-
"""
Created on Thu Jan 19 23:10:34 2023

@author: Administrator
"""


# @author :yongyao huang
# blog:https://www.cnblogs.com/yinzhengjie

from distutils.core import setup

setup(
    name='clietl',

    version='0.0.1',

    description='Python automatic operation and maintenance platform',
    # 作者是谁，指的是此项目开发的人，这里就写你自己的名字即可
    author='yongyao huang',

    author_email='yongyao.huang95@gmail.com',

    url='https://www.cnblogs.com/yinzhengjie/p/14124623.html',

    packages=['etlcli'],
)